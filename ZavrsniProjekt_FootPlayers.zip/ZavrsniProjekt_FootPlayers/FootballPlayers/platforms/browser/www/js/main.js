var reqIgrac;
var podaci;
var idPodatkaa;
var db;
var shortName = 'MojaBaza';
var version = '1.0';
var displayName = 'Moja WebSQL baza';
var maxSize = 65535;
var API_key = "AIzaSyA3bByWfSenZTmJmIXKF601gxvUMy1U_Ag";

//Osiguravamo da nam se JS funckije izvršavaju tek kad je uređaj spreman
window.onload=function()
{

  document.addEventListener("deviceready",postavi);
  postavi();
  if(localStorage.getItem(0) == null)
  {
    idPodatkaa = 0;
  }else{
    idPodatkaa = localStorage.length;
  }
}

function postavi()
{
  document.getElementById("btnTrazi").addEventListener("click",uzmiTim);
  document.getElementById("btnProvjera").addEventListener("click",uzmiIgraca);
  document.getElementById('btnlocal').addEventListener("click",prikaziSve);
  document.getElementById('btnObrisi').addEventListener("click",obrisipopis);
  document.getElementById('btnDodajUBazu').addEventListener("click",dodajZapis);
  document.getElementById('btnbrisiBazu').addEventListener("click",ObrisiBazu);
  var opcije = {enableHighAccuracy : false}
  var brojac = navigator.geolocation.getCurrentPosition(dobro,lose,opcije);

}
function dobro(rez)
{
  document.getElementById("duzina").innerHTML="Vaša geografska dužina: " + rez.coords.longitude;
  document.getElementById("sirina").innerHTML="Vaša geografska širina: " + rez.coords.latitude;
  var url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+rez.coords.latitude+","+rez.coords.longitude+"&radius=500&types=food&key="+API_key;
  var zahtjev = new XMLHttpRequest();
  zahtjev.onreadystatechange=function()
  {
    if(zahtjev.status == 200 && zahtjev.readyState == 4)
    {
      var rezultat =zahtjev.responseText ;
      var podaci = JSON.parse(zahtjev.responseText);
      var prviobjekt=podaci.results[0].name;
      var drugiobjekt= podaci.results[1].name;
      //console.log(podaci);
      alert("Obrti/Restorani/Trgovački centri ili slično u blizini vas: "+"\n" + prviobjekt +"\n"+ drugiobjekt);
    }

  }
  zahtjev.open("GET",url,true);
  zahtjev.send();

}

function lose(greska)
{
  alert("Akcelerator ne radi: " + greska.message);
}

db = openDatabase(shortName,version,displayName,maxSize);
db.transaction(stvoriTablicu,errorHandler, sveOk);

function errorHandler(transaction,err)
{
    alert('Greška: ' + err.message + ' kod: ' + err.code);
}
function sveOk()
{
    console.log("Akcija izvrsena");
}
function stvoriTablicu(tx)
{
    tx.executeSql('CREATE TABLE IF NOT EXISTS Nogomet(UserId INTEGER NOT NULL PRIMARY KEY, ImePrezime TEXT NOT NULL)',[],sveOk,errorHandler);
}
function dodajZapis()
{
    db.transaction(dodaj,errorHandler,sveOk);
}
function dodaj(t)
{
    var igrac=document.getElementById('igracInput').value;
    t.executeSql('INSERT INTO Nogomet(ImePrezime) VALUES (?)',[igrac],sveOk,errorHandler);
}

function ObrisiBazu()
{
    db.transaction(function(t){t.executeSql( 'DROP TABLE Nogomet', [],sveOk,errorHandler);},errorHandler,sveOk);
    db.transaction(stvoriTablicu,errorHandler,sveOk);
}

function uzmiTim() {
  var IDklub=document.getElementById('idkluba').value;
  console.log(IDklub);
  reqIgrac = new XMLHttpRequest();
  reqIgrac.withCredentials = false;
  reqIgrac.open('GET', 'http://api.football-data.org/v1/teams/'+IDklub,true);
  reqIgrac.setRequestHeader("x-auth-token", "489e28185b3f40ac90ad2f00f69afd6a");
  reqIgrac.setRequestHeader("cache-control", "no-cache");
  reqIgrac.onreadystatechange = primiTim;
  //console.log("proslo");
  reqIgrac.send();
}
function uzmiIgraca() {
  var IDklub=document.getElementById('idkluba').value;
  console.log(IDklub);
  reqIgrac = new XMLHttpRequest();
  reqIgrac.withCredentials = false;
  reqIgrac.open('GET', 'http://api.football-data.org/v1/teams/'+IDklub+'/players',true);
  reqIgrac.setRequestHeader("x-auth-token", "489e28185b3f40ac90ad2f00f69afd6a");
  reqIgrac.setRequestHeader("cache-control", "no-cache");
  reqIgrac.onreadystatechange = provjeraIgraca;
  //console.log("proslo");
  reqIgrac.send();
}


// Obrada zatjeva
function primiTim() {
  // Provjeravamo je li zahtjev obrađen do kraja i OK
  if (reqIgrac.readyState == 4 && reqIgrac.status == 200){
    console.log(reqIgrac.responseText);
    // Parsiranje JSON podataka i spremanje u varijablu
    var podaci = JSON.parse(reqIgrac.responseText);
    var tim = podaci.name;
    var length=podaci.count;
    document.getElementById("klubb").innerHTML = "Vaš klub je  "+tim;

  }



}

function provjeraIgraca() {
  // Provjeravamo je li zahtjev obrađen do kraja i OK
  if (reqIgrac.readyState == 4 && reqIgrac.status == 200){
    //console.log(reqIgrac.responseText);
    // Parsiranje JSON podataka i spremanje u varijablu
    var podaci = JSON.parse(reqIgrac.responseText);
    var tim = podaci._links.team.href;
    var length=podaci.count;
    var Igracc=document.getElementById('igracInput').value;
    for(i=0;i<length;i++)
    {
        if(Igracc==podaci.players[i].name)
        {
          //console.log(podaci.players[i].name);
          var ugovor = podaci.players[i].contractUntil;
          var drzava= podaci.players[i].nationality;
          var igrac = podaci.players[i].name;
          var brojNaDresu = podaci.players[i].jerseyNumber;
          var pozicija = podaci.players[i].position;
          var datumRodenja = podaci.players[i].dateOfBirth;
          localStorage.setItem(idPodatkaa, Igracc);
          idPodatkaa += 1;
          document.getElementById("rezultat").innerHTML ="Player: "+igrac +"<br>" +"Position: "+pozicija+"<br>"+"Number: "+brojNaDresu+"<br>"+"Date of birth: "+datumRodenja+"<br>"+"Nationality: "+drzava+"<br>"+"Contract until: "+ugovor;
          break;
        }
        else {
          document.getElementById("rezultat").innerHTML ="Pogrešan unos. Molimo unesite pravilno ime i prezime igrača(primjer: Andrej Kramaric)";
        }

    }


  }

}
function obrisipopis()
{
  localStorage.clear();
  idPodatkaa = 0;

}

function prikaziSve(){

  var string="Popis igrača:  \n";

  var duljina =localStorage.length;
  for (i=0; i<duljina;i++){
    var kljuc = localStorage.key(i);
    var vrijednost = localStorage.getItem(kljuc);
    var element = kljuc +" "+vrijednost;
    string+=vrijednost+"\n";
  }

  alert(string);

}
