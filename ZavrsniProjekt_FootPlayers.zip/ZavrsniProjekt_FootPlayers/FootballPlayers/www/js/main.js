var reqIgrac;
var podaci;
var idPodatkaa;
var db;
var shortName = 'MojaBaza';
var version = '2.0';
var displayName = 'Moja WebSQL baza';
var maxSize = 65535;
//var API_key = "AIzaSyA3bByWfSenZTmJmIXKF601gxvUMy1U_Ag";
//var API_key = "5bd28e45417f403f9976815a9e751de3";
var API_key = "9d913730c7764ebeab8132101bd4ccb1";

var API_maps = "AIzaSyCyvvzadSBgCdAz3OWk98hAzA_X_xnsW1Y";
//var API_maps = "AIzaSyAfXUT6wruOgAWJU9VXLZT_tzWugmPnLeI";
headers: { 'X-Auth-Token',  '9d913730c7764ebeab8132101bd4ccb1' };

 
//Osiguravamo da nam se JS funckije izvršavaju tek kad je uređaj spreman
window.onload=function()
{

  document.addEventListener("deviceready",postavi);
  postavi();
  if(localStorage.getItem(0) == null)
  {
    idPodatkaa = 0;
  }else{
    idPodatkaa = localStorage.length;
  }
  
  
}

function postavi()
{
  document.getElementById("btnTrazi").addEventListener("click",uzmiTim);
  document.getElementById("btnTraziLigu").addEventListener("click",uzmiStrijelce);
  document.getElementById("btnProvjera").addEventListener("click",uzmiIgraca);
  document.getElementById('btnDodajUBazu').addEventListener("click",dodajZapis);
  document.getElementById('btnbrisiBazu').addEventListener("click",ObrisiBazu);
  var opcije = {enableHighAccuracy : false}
  var brojac = navigator.geolocation.getCurrentPosition(dobro,lose,opcije);

}
function dobro(rez)
{
  document.getElementById("duzina").innerHTML="Vaša geografska dužina: " + rez.coords.longitude;
  document.getElementById("sirina").innerHTML="Vaša geografska širina: " + rez.coords.latitude;
  var url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+rez.coords.latitude+","+rez.coords.longitude+"&radius=500&types=food&key="+API_maps;
  var zahtjev = new XMLHttpRequest();
  zahtjev.onreadystatechange=function()
  {
    if(zahtjev.status == 200 && zahtjev.readyState == 4)
    {
      var rezultat =zahtjev.responseText ;
      var podaci = JSON.parse(zahtjev.responseText);
    }

  }
  zahtjev.open("GET",url,true);
  zahtjev.send();

}

function lose(greska)
{
  alert("Akcelerator ne radi: " + greska.message);
}

db = openDatabase(shortName,version,displayName,maxSize);
db.transaction(stvoriTablicu,errorHandler, sveOk);

function errorHandler(transaction,err)
{
    alert('Greška: ' + err.message + ' kod: ' + err.code);
}
function sveOk()
{
    console.log("Akcija izvrsena");
}
function stvoriTablicu(tx)
{
    tx.executeSql('CREATE TABLE IF NOT EXISTS Nogomet(UserId INTEGER NOT NULL PRIMARY KEY, ImePrezime TEXT NOT NULL)',[],sveOk,errorHandler);
}
function dodajZapis()
{
    db.transaction(dodaj,errorHandler,sveOk);
}
function dodaj(t)
{
    var igrac=document.getElementById('igracInput').value;
	if (reqIgrac.readyState == 4 && reqIgrac.status == 200){
    var podaca = JSON.parse(reqIgrac.responseText);
	var imeIgraca = podaca.name;
	}
    t.executeSql('INSERT INTO Nogomet(ImePrezime) VALUES (?)',[imeIgraca],sveOk,errorHandler);
}

function ObrisiBazu()
{
    db.transaction(function(t){t.executeSql( 'DROP TABLE Nogomet', [],sveOk,errorHandler);},errorHandler,sveOk);
    db.transaction(stvoriTablicu,errorHandler,sveOk);
}

function uzmiTim() {
  var IDklub=document.getElementById('idkluba').value;
  //console.log(IDklub);
  reqIgrac = new XMLHttpRequest();
  reqIgrac.withCredentials = false;
  reqIgrac.open('GET', 'http://api.football-data.org/v2/teams/'+IDklub,true);
  //reqIgrac.setRequestHeader("x-auth-token", "489e28185b3f40ac90ad2f00f69afd6a");
  reqIgrac.setRequestHeader("x-auth-token", "9d913730c7764ebeab8132101bd4ccb1");
  reqIgrac.setRequestHeader("cache-control", "no-cache");
  reqIgrac.onreadystatechange = primiTim;
  //console.log("proslo");
  reqIgrac.send();
  
  
}
function uzmiIgraca() {
  //var IDklub=document.getElementById('idkluba').value;
  var IDigrac=document.getElementById('igracInput').value;
  //console.log(IDklub);
  reqIgrac = new XMLHttpRequest();
  reqMec = new XMLHttpRequest();
  reqIgrac.withCredentials = false;
  reqMec.withCredentials = false;
  reqIgrac.open('GET', 'http://api.football-data.org/v2/players/'+IDigrac,true);
  reqMec.open('GET', 'http://api.football-data.org/v2/players/'+IDigrac+'/matches',true);
  reqIgrac.setRequestHeader("x-auth-token", "9d913730c7764ebeab8132101bd4ccb1");
  reqIgrac.setRequestHeader("cache-control", "no-cache");
  reqIgrac.onreadystatechange = provjeraIgraca;
  reqMec.setRequestHeader("x-auth-token", "9d913730c7764ebeab8132101bd4ccb1");
  reqMec.setRequestHeader("cache-control", "no-cache");
  reqMec.onreadystatechange = provjeraIgraca;
  reqIgrac.send();
  reqMec.send();
  
}

function uzmiStrijelce(){
	var kodLige=document.getElementById('kodkluba').value;
	reqCom = new XMLHttpRequest();
	reqCom.withCredentials = false;
	reqCom.open('GET', 'https://api.football-data.org/v2/competitions/'+kodLige+'/scorers',true);
	reqCom.setRequestHeader("x-auth-token", "9d913730c7764ebeab8132101bd4ccb1");
	reqCom.setRequestHeader("cache-control", "no-cache");
	reqCom.onreadystatechange = provjeraStrijelci;
	reqCom.send();
	
	
}

function provjeraStrijelci(){
	if (reqCom.readyState == 4 && reqCom.status == 200){
		var podaciCom = JSON.parse(reqCom.responseText);
		var lista = [];
		for(i=1; i < 11;i++) {
		lista.push(i+"."+podaciCom.scorers[i-1].player.name+"\n");
	}
	var listanova = lista.join('');
	window.alert("Najbolji strijelce lige: "+"\n"+listanova);
	}
	else if (reqCom.readyState != 4 && reqCom.status != 200) {
		window.alert("krivi unos");
	}
}


// Obrada zatjeva
function primiTim() {
  // Provjeravamo je li zahtjev obrađen do kraja i OK
  if (reqIgrac.readyState == 4 && reqIgrac.status == 200){
    console.log(reqIgrac.responseText);
    // Parsiranje JSON podataka i spremanje u varijablu
    var podaci = JSON.parse(reqIgrac.responseText);
    var tim = podaci.name;
	var osnovanje = podaci.founded;
    var length=podaci.count;
	var ekipa = [];
	for (i=0;i < podaci.squad.length - 1;i++) {
		ekipa.push(podaci.squad[i].name+"("+podaci.squad[i].id+")");
		
	}

	window.alert("Vaš klub je  "+tim + "\n"+"Osnovan: "+osnovanje);
    //document.getElementById("klubb").innerHTML = "Vaš klub je  "+tim + "<br>"+"Osnovan: "+osnovanje;
    window.alert("Igrači: "+ekipa + "(Trener)");
  }



}

function provjeraIgraca() {
  // Provjeravamo je li zahtjev obrađen do kraja i OK
  if (reqIgrac.readyState == 4 && reqIgrac.status == 200 && reqMec.readyState == 4 && reqMec.status == 200 ){
    //console.log("aaa: "+ reqIgrac.responseText);
    // Parsiranje JSON podataka i spremanje u varijablu
    var podaci = JSON.parse(reqIgrac.responseText);
	var podaciMec = JSON.parse(reqMec.responseText);
    var length=podaci.count;
    var Igracc=document.getElementById('igracInput').value;
    if(Igracc==podaci.id)
        {
          
          var drzava= podaci.nationality;
          var igrac = podaci.name;
          var pozicija = podaci.position;
          var datumRodenja = podaci.dateOfBirth;
          localStorage.setItem(idPodatkaa, Igracc);
          idPodatkaa += 1;
		  window.alert("Igrac: "+ igrac + "\n"+"Nacionalnost: " + drzava + "\n"+"Datum rodenja : "+datumRodenja + "\n"+"Pozicija: "+pozicija);
		  
        }
    else {
		window.alert("Pogrešan unos.");
        }

    


  }
  

	
  
	



}
/*function obrisipopis()
{
  localStorage.clear();
  idPodatkaa = 0;

}*/

/*function prikaziSve(){
  
   
  //var string="Popis pretrazenih ID-ova:  \n";
  //console.log(localStorage);
  
  var string = [];
  var IDigrac=document.getElementById('igracInput').value;
  //console.log(IDklub);
  reqIgrac = new XMLHttpRequest();
  reqIgrac.withCredentials = false;
  reqIgrac.open('GET', 'http://api.football-data.org/v2/players/'+IDigrac,true);
  
  //reqIgrac.open('GET', 'http://api.football-data.org/v2/teams/'+IDklub+'/players',true);
  //reqIgrac.setRequestHeader("x-auth-token", "489e28185b3f40ac90ad2f00f69afd6a");
  reqIgrac.setRequestHeader("x-auth-token", "9d913730c7764ebeab8132101bd4ccb1");
  reqIgrac.setRequestHeader("cache-control", "no-cache");
  //reqIgrac.onreadystatechange = provjeraIgraca;
  //console.log("proslo jeeeeeeeeee");
  reqIgrac.send();
  //var duljina =localStorage.length;
  //for (i=0; i<duljina;i++){
	
    //var kljuc = localStorage.key(i);
	
    //var vrijednost = localStorage.getItem(kljuc);
	//var imeee = vrijednost.name;
	
    //var element = kljuc +" "+vrijednost;
	
	//string+=imeIgracaa+"\n";
	
  if (reqIgrac.readyState == 4 && reqIgrac.status == 200){
    console.log("uslo");
    // Parsiranje JSON podataka i spremanje u varijablu
    var podace = JSON.parse(reqIgrac.responseText);
	var imeIgracaa = podace.name;
	string.push(imeIgracaa);
	
  }
  alert(string);
    
  //}

  //alert(string);

}*/
